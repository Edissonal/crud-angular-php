import {ModuleWithProviders}  from '@angular/core';
import {Routes,RouterModule}  from '@angular/router';
import { AddproComponent } from '../app/productos/addpro/addpro.component';


//componentes

import {HomeComponent} from './home/home.component';
import { ErrorComponent } from './error/error.component';
import { ProductosComponent } from './productos/productos/productos.component';
const appRoutes :Routes =[
    {path:'',component:HomeComponent},
    {path:'Home',component:HomeComponent},
    {path:'productos',component:ProductosComponent},
    {path:'addpro',component:AddproComponent},
    {path:'**',component:ErrorComponent},
   
];


export const  appRoutingProviders:any[] =[];
export const routing:ModuleWithProviders = RouterModule.forRoot(appRoutes);

