export  var Global ={
  url:'http://localhost/curso-angular4/index.php/',
  header_color:'#e03137'
}