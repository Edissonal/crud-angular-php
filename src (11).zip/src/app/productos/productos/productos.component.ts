import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute,Params}  from '@angular/router';
import {ProductoService}  from '../../services/producto.service';
import{Producto} from '../../models/producto';

@Component({
  selector: 'app-productos',
  templateUrl: './productos.component.html',
  styleUrls: ['./productos.component.css'],
})
export class ProductosComponent implements OnInit {
public titulo:string;
public productos:Producto[];
 
  constructor(
    private activatedRoute:ActivatedRoute,
    private router:Router,
    private productoService:ProductoService
  ) { 
    this.titulo ="Listado de productos";
    
  }

  ngOnInit() {
console.log('productos-list.component.txt cargado');
 this.productoService.getProductos().subscribe(
   result =>{
//console.log(result);
this.productos =result.data;

if(result.code !=200){
  console.log(result);
  }else{
   this.productos =result.data;
  }
   },error=>{
console.log(<any>error);
   }
 );
   }

}
