import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute,Params}  from '@angular/router';
import {ProductoService}  from '../../services/producto.service';
import{Producto} from '../../models/producto';
import{Global} from '../../services/global';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-addpro',
  templateUrl: './addpro.component.html',
  styleUrls: ['./addpro.component.css']
})
export class AddproComponent implements OnInit {
public titulo:string;
public producto:Producto;
public filesToUpload;
public resultupload;

  constructor(
    private productoService:ProductoService,
    private activatedRoute:ActivatedRoute,
    private router:Router,
    
                ) {
    this.titulo ='Crear Producto';
    this.producto = new Producto(0,'','',0,'');
  }

  ngOnInit() {
    console.log('Producto add cargado');
  }

  onSubmit(){
    console.log(this.producto);
    if(this.filesToUpload.length && this.filesToUpload.length >= 1){
      this.productoService.makeFileRequest(Global.url+'upload-file',[],this.filesToUpload).then((result) =>{
      console.log(result);
      this.resultupload = result;
      this.producto.imagen = this.resultupload.filename;
      this.saveProducto();
   
  
    },error =>{
      console.log(error);
    });

  }else{
    this.saveProducto();
  }
  }

  saveProducto(){
    
    
    this.productoService.addproducto(this.producto).subscribe(
      response => {
      if(response.code ==200){
       this.router.navigate(['/Home'])
      }else{
        console.log(response);
      }
      },
      error =>{
   console.log(<any>error);
      }
    );
  }


  fileChangeEvent(fileInput: any){
		this.filesToUpload = <Array<File>>fileInput.target.files;
    console.log(this.filesToUpload);
    console.log("Hola muando");
  }
  


}

