<?php
require_once 'vendor/autoload.php';

$app= new \Slim\Slim();

$db = new mysqli('localhost','root','','curso-angular4');
//configuracion de cabeceras
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
$method = $_SERVER['REQUEST_METHOD'];
if($method == "OPTIONS") {
    die();
}

$app ->get("/pruebas",function()use($app,$db){
    echo "Holamundo desde slim";
    var_dump($db);

});

$app ->get("/provando",function()use($app){
    echo "Este es otro metodo ";

});



//listar todos los productos
$app -> get('/productos',function()use($app,$db){
    $sql ='select * from productos order by id desc;';
    $query =$db ->query($sql);
    $productos =array();
    while($producto = $query -> fetch_assoc()){
     $productos[] =$producto;
    }
    $result = array(
        'status' => 'success',
        'code' =>200,
        'data' => $productos
    );
    echo json_encode($result);
});

//dovolver un solo producto
$app ->get('/producto/:id',function($id)use($db, $app){
$sql='select * from productos where id ='.$id;
$query =$db ->query($sql);
$result = array (
 "status"=> "error",
 "code" => "404",
 "message" => "Producto no disponible"
);
if($query ->num_rows == 1 ){
 $producto = $query ->fetch_assoc();  
 
 $result = array (
 "status"=> "success",
 "code" => "200",
 "data" => $producto
);
}
echo json_encode($result);
});

//eliminar producto
$app ->get('/delete-producto/:id',function($id)use($db,$app){
$sql ="delete from productos where id=".$id;
$query =$db ->query($sql);
if($query){
    $result = array (
        "status"=> "success",
        "code" => "200",
        "message" => "El producto se a eliminado correctamente"
       );
}else{
    $result = array (
        "status"=> "error",
        "code" => "404",
        "message" => "El producto no se a eliminado correctamente"
       );
}
echo json_encode($result);
});
//actualizar

$app -> post("/update-producto/:id",function($id)use($db,$app){
    $json = $app->request->post('json');
    $data = json_decode($json,true);
    $sql = "UPDATE productos SET ".
    "nombre = '{$data["nombre"]}', ".
    "description = '{$data["description"]}',";
    if(isset($data['imagen'])){
        "imagen = '{$data["imagen"]}',";
    }
    $sql.="precio = '{$data["precio"]}' where id = {$id}"; 
   

      $query = $db ->query($sql);
      var_dump($sql);

      if($query){
        $result = array (
            "status"=> "success",
            "code" => "200",
            "message" => "El producto  se a actualizado correctamente"
           );
      }else{
        $result = array (
            "status"=> "error",
            "code" => "404",
            "message" => "El producto no se a actualizado correctamente"
           );
      }
  echo json_encode($result);
});
//subir archivos

$app ->post ('/upload-file',function() use($db,$app){

    $result = array (
        "status"=> "error",
        "code" => "404",
        "message" => "el archivo no a podido subirse"
       );
       if(isset($_FILES['uploads'])){
          //     echo "lleganlos datos";
        $piramideUploader = new PiramideUploader();
        $upload = $piramideUploader->upload('image', "uploads", "uploads", array('image/jpeg', 'image/png', 'image/gif'));
		$file = $piramideUploader->getInfoFile();
		$file_name = $file['complete_name'];
           //var_dump($file);
           if(isset($upload)&& $upload["uploaded"] == false){
            
            $result = array (
                "status"=> "error",
                "code" => "404",
                "message" => "el archivo no a podido subirse"
               );
           }else{
            $result = array (
                "status"=> "success",
                "code" => "200",
                "message" => "el archivo se subio",
                "filename"=> $file_name
               ); 
           }

       }
       echo json_encode($result);
});
//guardar productos

$app -> post('/productos',function()use($app,$db){

    $json =$app->request->post('json');
    $data =json_decode($json,true);
    //var_dump($json);
    //var_dump($data);
    
    if(!isset($data['nombre'])){
        $data['nombre']=null;
    }
        
    if(!isset($data['descripcion'])){
        $data['descripcion']=null;
    }
    if(!isset($data['precio'])){
        $data['precio']=null;
    }
    if(!isset($data['imagen'])){
        $data['imagen']=null;
    }
    
    $query ="insert into productos values (null,".
        "'{$data['nombre']}',".  
        "'{$data['descripcion']}',".
        "'{$data['precio']}',".  
        "'{$data['imagen']}'".   
        
    ");";
    $insert = $db ->query($query);

   
    if($insert){
        $result = array(
        'status' => 'error',
        'code' =>404,
        'message' => 'Prducto  no creado correctamente'
    );
    }
    if($insert){
        $result = array(
        'status' => 'success',
        'code' =>200,
        'message' => 'Prducto creado correctamente'
    );
    }
    echo json_encode($result);
});
$app ->run();
?>